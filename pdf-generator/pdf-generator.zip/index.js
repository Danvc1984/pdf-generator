const puppeteer = require("puppeteer");
const fs = require("fs-extra");
const hbs = require("handlebars");
const path = require("path");

const data = {
  name: "daniel",
  age: 12,
  listed: "chevrons",
  /* images can't be directly accessed from local file system, 
  apparently there is a few options to workaround this (https://github.com/puppeteer/puppeteer/issues/1643)
  currently using the 'encode images as inline html' option
  */
  logo: `data:image/svg+xml;base64,${fs
    .readFileSync("./templates/logo.svg")
    .toString("base64")}`,
};

const compile = async function (templateName, data) {
  const filePath = path.join(process.cwd(), "templates", `${templateName}.hbs`);
  const html = await fs.readFile(filePath, "utf-8");
  return hbs.compile(html)(data);
};

(async function () {
  console.log("started");
  try {
    const content = await compile("demo2", data);
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    //Next line commands puppeter to wait for external dependencies to be loaded
    await page.goto(`data:text/html;charset=UTF-8,${content}`, {
      waitUntil: "networkidle0",
    });
    await page.setContent(content);
    await page.emulateMediaType("print");
    await page.pdf({
      path: "demo.pdf",
      format: "A4",
      printBackground: true,
    });
    console.log("done");
    await browser.close();
    process.exit();
  } catch (error) {
    console.log(error);
    process.exit();
  }
})();
